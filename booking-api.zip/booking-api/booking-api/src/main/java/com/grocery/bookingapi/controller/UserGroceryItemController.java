package com.grocery.bookingapi.controller;

import com.grocery.bookingapi.mapper.UrlMapping;
import com.grocery.bookingapi.model.GroceryItem;
import com.grocery.bookingapi.model.Orders;
import com.grocery.bookingapi.service.GroceryItemService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Slf4j
public class UserGroceryItemController {
    @Autowired
    private GroceryItemService groceryItemService;

    @GetMapping(value = UrlMapping.USER_GET_GROCERY_ITEMS)
    public ResponseEntity<List<GroceryItem>> getAvailableGroceryItems() {
        return ResponseEntity.ok(groceryItemService.getAvailableGroceryItems());
    }
    @PostMapping(value =UrlMapping.USER_BOOK_MULTIPLE_GROCERY_ITEMS)
    public ResponseEntity<Orders> bookGroceryItems(@RequestBody List<GroceryItem> orderItems) {
        log.info("Book Multiple Grocery Items");
        Orders order = groceryItemService.bookGroceryItems(orderItems);
        return ResponseEntity.ok(order);
    }
}
