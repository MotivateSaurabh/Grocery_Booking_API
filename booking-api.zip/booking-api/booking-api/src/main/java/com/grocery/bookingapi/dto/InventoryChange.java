package com.grocery.bookingapi.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class InventoryChange {
    private int changeAmount;
}
