package com.grocery.bookingapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookingApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
